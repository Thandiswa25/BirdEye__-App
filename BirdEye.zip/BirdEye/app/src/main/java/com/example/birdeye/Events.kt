package com.example.birdeye

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Events : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_events)

        // Fetch and display upcoming events
        // You can replace this with your own logic to fetch events from a database or server

        val upcomingEvents = getUpcomingEvents()
        displayEvents(upcomingEvents)
    }

    // Sample method to get a list of upcoming events
    private fun getUpcomingEvents(): List<Events> {
        // Replace this with your logic to fetch events from a database or server
        // For now, let's create a sample list of events
        return listOf(
            Events("Event 1", "Description 1", "Date 1"),
            Events("Event 2", "Description 2", "Date 2"),
            Events("Event 3", "Description 3", "Date 3")
            // Add more events as needed
        )
    }

    // Sample method to display events in a TextView
    private fun displayEvents(events: List<Events>) {
        val eventsText = StringBuilder()

        for (event in events) {
            eventsText.append("Event: ${event.name}\n")
            eventsText.append("Description: ${event.description}\n")
            eventsText.append("Date: ${event.date}\n\n")
        }

        val textEvents: TextView = findViewById(R.id.textEvents)
        textEvents.text = eventsText.toString()
    }
    data class Events(val name: String, val description: String, val date: String)
}