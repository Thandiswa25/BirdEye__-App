
package com.example.birdeye

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class BirdDetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bird_details)

        val birdName = intent.getStringExtra("birdName")
        val birdDescription = intent.getStringExtra("birdDescription")

        val textBirdName: TextView = findViewById(R.id.textBirdName)
        val textBirdDescription: TextView = findViewById(R.id.textBirdDescription)

        // Check if birdName is not null before setting the text
        if (birdName != null) {
            textBirdName.text = birdName
        } else {
            textBirdName.text = "No name available"
        }

        // Check if birdDescription is not null before setting the text
        if (birdDescription != null) {
            textBirdDescription.text = birdDescription
        } else {
            textBirdDescription.text = "No description available"
        }
    }
}

