package com.example.birdeye

data class BirdEye(val obs_id:String? = null, val birdName:String? = null ,val birdNotes:String? = null) {

}
